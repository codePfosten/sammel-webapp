# Sammel-App · Startpaket

Stand: 23.10.2026 · Architekturentwurf 0.1 · Privates Projekt

Dieses Paket ist die konkrete Grundlage zum Anlegen eines Repositorys. Es enthält Planung, Agentenregeln und eine eigenständig öffnende UI-Vorschau. **Es enthält noch keine implementierte Sammel-App und kein fertig eingerichtetes React-Projekt.** Alle App-Funktionen sind geplant; die Vorschau zeigt ausschließlich fiktive Beispieldaten.

## So startest du

1. ZIP entpacken. Die Inhalte dieses Ordners bilden die vorgesehene Repository-Wurzel.
2. [UI-Vorschau öffnen](docs/preview/ui-preview.html): ohne Installation, ohne Internet, ohne Speicherung. Alternativ [Bildübersicht](docs/preview/screens.svg).
3. Den Inhalt von [BOOTSTRAP_AGENT_PROMPT.md](prompts/BOOTSTRAP_AGENT_PROMPT.md) einem Coding-Agenten geben und dieses gesamte Paket als Kontext/Dateien bereitstellen.
4. Der Agent richtet das lokale Projekt ein und erstellt einen navigierbaren Demo-Prototyp. Er prüft zuerst ein eventuell vorhandenes Repository, ergänzt es vorsichtig und veröffentlicht nichts.

## Für dich: sehen, was entstehen soll

| Übersicht | Inhalt |
|---|---|
| [UI_PREVIEW.md](UI_PREVIEW.md) | Bildschirmkonzept und visuelle Vorschau |
| [PROJECT_FLOW.md](PROJECT_FLOW.md) | Navigation und Entwicklungsablauf |
| [CLASS_DIAGRAM.md](CLASS_DIAGRAM.md) | Modell, Beziehungen und Implementierungsstatus |
| [FEATURE_CHECKLIST.md](FEATURE_CHECKLIST.md) | Was geplant, begonnen und fertig ist |

## Für Agenten: verstehen, wo etwas hingehört

| Dokument | Zweck |
|---|---|
| [AGENTS.md](AGENTS.md) | Gemeinsame Arbeitsregeln und Kontextreihenfolge |
| [Aktueller Umfang](docs/product/CURRENT_SCOPE.md) | Neueste Vorgaben und Grenzen des Startauftrags |
| [Architektur](docs/architecture/ARCHITECTURE.md) | Schichten, Stack, Abhängigkeiten und Betrieb |
| [Repository-Struktur](docs/architecture/REPOSITORY_MAP.md) | Konkrete Zielpfade und Zuständigkeiten |
| [Datenmodell und Verträge](docs/architecture/DATA_CONTRACTS.md) | Typen, Ports, Defaults und Fehler |
| [Entscheidungen](docs/architecture/DECISIONS.md) | Arbeitsannahmen und spätere Entscheidungen |
| [UI-Spezifikation](docs/ui/UI_SPEC.md) | Routen, Komponenten und Zustände |
| [Aufgabenfolge](docs/planning/TASKS.md) | Kleine, getrennt bearbeitbare Arbeitspakete |
| [Prüfplan](docs/planning/ACCEPTANCE.md) | Kriterien je Entwicklungsstufe |
| [Übergabeprotokoll](docs/planning/STATUS.md) | Tatsächlicher Stand, Prüfungen und nächster Schritt |
| [Quellen](docs/architecture/SOURCES.md) | Technische Grundlagen und Grenzen |

Die Originaldateien liegen unverändert in `docs/product/`. Aktuelle Ergänzungen stehen separat in `CURRENT_SCOPE.md`. Die vollständige ursprüngliche `VISUAL_OVERVIEW_AGENT.md` wurde nicht mitgeliefert; sie wird nicht rekonstruiert. Bis sie vorliegt, pflegt der jeweils arbeitende Agent die Übersichten selbst.

## Lokal starten – erst nach dem Bootstrap

Der Bootstrap-Agent soll `npm run dev`, `npm run build`, `npm run typecheck`, `npm run lint` und `npm run test:run` einrichten und die tatsächlich gewählten Toolversionen dokumentieren. Diese Befehle funktionieren mit dem reinen Dokumentationspaket noch nicht.

Die spätere App läuft im Browser. Ein Entwicklungsserver auf dem Rechner liefert die Dateien; ein eigener fachlicher Backend-Server ist zunächst nicht vorgesehen. Ein privater, auf dem iPhone offline startbarer Betrieb ist ein späterer, eigener Schritt.
